public class ToStringDemo
{
    public static void main(String[] args)
    {
        BankAccount acc = new BankAccount("12345678", "Patel");
        System.out.println(acc);
    }
}
