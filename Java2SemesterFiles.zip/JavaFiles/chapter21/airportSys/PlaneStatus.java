
package airportSys; // add to package

/**
* Enumerated plane status type.
*
* @author Charatan and Kans
* @version 1st August 2018
*/
public enum PlaneStatus
{
DUE, WAITING, LANDED, DEPARTING
}

