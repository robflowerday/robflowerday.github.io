public interface Computable
{
    public double compute(double x, double y);
}