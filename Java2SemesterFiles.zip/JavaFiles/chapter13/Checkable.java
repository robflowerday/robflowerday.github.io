public interface Checkable
{
	public boolean check();
}
