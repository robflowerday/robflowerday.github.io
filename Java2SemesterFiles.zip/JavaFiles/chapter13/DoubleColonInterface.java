public interface DoubleColonInterface
{
    //public void test(String s);
    public double test(int i);
}
