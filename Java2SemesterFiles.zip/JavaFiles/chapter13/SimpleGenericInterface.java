public interface SimpleGenericInterface<T, V>
{
    public V doSomething(T valueIn);
}
