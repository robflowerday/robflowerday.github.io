public interface Calculatable
{
    //    public double calculateSurfaceArea();
        public double calculateVolume();
}