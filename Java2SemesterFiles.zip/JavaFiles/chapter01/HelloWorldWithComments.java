
// this is a short comment, so we use the first method 

public class HelloWorldWithComments
{
     public static void main(String[] args)
     {
          System.out.println("Hello world");
     }

/* this is the second method of including comments – it is more convenient to use
   this method here, because the comment is longer and goes over more than one line */

}
