public class HelloWorldWithAnAdditionalLine
{
     public static void main(String[] args)
     {
          System.out.println("Hello world"); // notice the use of println 
          System.out.println("Hello world again!");
     }
}
