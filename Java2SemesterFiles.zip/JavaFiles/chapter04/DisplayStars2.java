
public class DisplayStars2
{
    public static void main (String[] args)
    {  
        for(int i = 1; i <= 5; i++) // loop to repeat 5 times
        {
            System.out.println("*****"); // instruction to display one row
        }
    }
}

