
public class Countdown
{
    public static void main(String[] args)
    {
        System.out.println("*** Numbers from 10 to 1 ***");
        System.out.println();
        for (int i=10; i >= 1; i--) // counter moving down from 10 to 1
        {
            System.out.println(i);
        }
    }
}

